function Calculate(a, b, operand){
    let response;
    switch(operand){
        case '+':
            response = a + b;
            break;
        case '-':
            response = a - b;
            break;
        case '*':
            response = a * b;
            break;
        case '/':
            if(b != 0){
                response = a / b;
            }
            else{
                response = 'Can not divide by zero!';
            }
            break;
    }

    return response;
}

function PreCalc(aIdentifier, bIdentifier, operandIdentifier, targetIdentifier){
    document.getElementById(targetIdentifier).value =
        Calculate(
        parseInt(document.getElementById(aIdentifier).value),
        parseInt(document.getElementById(bIdentifier).value),
        document.getElementById(operandIdentifier).value);
}